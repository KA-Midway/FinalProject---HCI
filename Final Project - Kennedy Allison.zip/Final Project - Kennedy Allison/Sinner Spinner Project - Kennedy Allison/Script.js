var wheel = document.getElementById("wheel");
var spinBtn = document.getElementById("spinBtn");
var result = document.getElementById("result");

var names = ["Red", "Orange", "Yellow", "Green", "Blue", "Purple", "Pink", "White", "Aqua", "Brown", "LightGreen", "BloodRed", "Gold", "Grey"];

var info={
	Red: "Rodya: Morally conflicted, determined, and guilt-driven",
	Orange: "Ishmael: Determined, persevering, and focused on ambitious goals",
	Yellow: "Don Quixote: Idealistic, courageous, yet occasionally reckless",
	Green: "Outis: Calculating and deceptive",
	Blue: "Mersault: Detached, stoic, and resilient",
	Purple: "Heathcliff: Brooding, intense, and vengeful",
	Pink: "Faust: Supportive, intelligent, and strategic",
	White: "Yi Sang: Reflective, artistic, and introspective",
	Aqua: "Hong Lu: Agile, perceptive, and evasive",
	Brown: "Gregor: Adaptable and balanced",
	LightGreen: "Sinclair: Balanced and independent, combining cautious offense with self-sustainability",
	BloodRed: "Ryoshu: Aggressive and fast-paced",
	Gold: "Dante: Versatile, composed, and managerial",
	Grey: "Vergilious: Rational, disciplined, morally strict, and introspective"
	
	//This is the only part that I used AI on as I wanted to give a brief overviw of all of the sinners without lossing elements that are key to their characterization or give spoilers to their cantos
	//search up summarize every limbus comapny sinner's personalitiy and then after could you do the same for vergilious? in google ai to get where I got the answers. No other sections we made with AI
	//Version Used: Copilot 1.25103.108.0
	//The ouput was only used to show what the personality of the sinners are and nothing else was utilised that had to use ai and was directly included
};

var total = 0;
var current = 0;
var slice = 360/names.length;
var picked = 0;

function mod360(x){
	var r = x%360;
	return r<0? (r+360):r;
}

function centerAngle(i){
	return i*slice+slice/2;
}

spinBtn.onclick=function(){
	picked = Math.floor(Math.random()*names.length);
	var target = centerAngle(picked);
	var baseDelta = mod360(360-target-current);
	total = total + baseDelta;
	current = mod360(total);
	
	result.textContent = "Spinning...";
	spinBtn.disabled = true;
	
	console.log(target);
	
	wheel.style.transform = "rotate("+total+"deg)";
};

wheel.addEventListener("transitionend", function(){
	var colorname =  names[picked];
	result.textContent = info[colorname];
	spinBtn.disabled = false;
});