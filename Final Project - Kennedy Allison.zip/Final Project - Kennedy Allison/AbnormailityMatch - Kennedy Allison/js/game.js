const spanPlayer = document.querySelector(".player");
const grid = document.querySelector(".grid");
const timer = document.querySelector(".timer");

const characters=[
	'beth',
	'jerry',
	'jessica',
	'morty',
	'meeseeks',
	'pessoa-passaro',
	'pickle-rick',
	'rick',
	'scroopy',
	'summer'
];

let firstCard = "";
let secondCard = "";
let matchCount = 0;


const startTimer=()=>{
	this.loop = setInterval(()=>{
		currentTime =+ timer.innerHTML;
		timer.innerHTML = currentTime + 1;
	}, 
	1000);
};


function speakAddress(address) {
	if ('speechSynthesis' in window) {
		var speech = new SpeechSynthesisUtterance(address);
		speech.lang = 'en-US'; // Set the language to English
		window.speechSynthesis.speak(speech);
		} else {
		console.log("Speech synthesis not supported in this browser.");
    }
}


const createElement=(tag,className)=>{
	const element = document.createElement(tag);
	element.className = className;
	return element;
};

const createCard=(characters)=>{
	const card=createElement('div','card');
	const front=createElement('div','face front');
	const back=createElement('div','face back');
	front.style.backgroundImage=`url('../images/${characters}.png')`;
	card.appendChild(front);
	card.appendChild(back);
	card.addEventListener('click',revealCard);
	card.setAttribute('data-character',characters);//Note 13
	return card;
};

const revealCard=(event)=>{
	//console.log("I am clicked!");
	const target=event.target;
	
	console.log(target);
	console.log(target.parentNode);
	console.log(target.parentNode.className);

	
	if (target.parentNode.className.includes('reveal-card')){
		return;
	}
	
	if (firstCard===''){
		target.parentNode.classList.add('reveal-card');
		firstCard = target.parentNode;
	}else if (secondCard===''){
		target.parentNode.classList.add('reveal-card');
		secondCard = target.parentNode;
		
		setTimeout(()=>checkCards(),500);
		
	}
	
};

const loadGame=()=>{
	const repeatedCards=[...characters,...characters];//Note 14
	const shuffledArray=repeatedCards.sort(()=>Math.random()-0.5);//Note 15
	shuffledArray.forEach((characters)=>{//Note 16
		const card=createCard(characters);
		grid.appendChild(card);
	});
};

const checkCards=()=>{
	const firstCharacter = firstCard.getAttribute('data-character');
    const secondCharacter = secondCard.getAttribute('data-character');
	
	if (firstCharacter===secondCharacter){
		firstCard.firstChild.classList.add('disabled-card');
		secondCard.firstChild.classList.add('disabled-card');
		matchCount = matchCount + 2;
		
		firstCard = "";
		secondCard = "";
		
		setTimeout( ()=>{checkEndGame();}, 300)
	}else{
		setTimeout( ()=>{
				firstCard.classList.remove('reveal-card');
				firstCard = "";
		
				secondCard.classList.remove('reveal-card');
				secondCard = "";	
			}, 500 
		);

	}
	
};

const checkEndGame=()=>{
	if(2 * characters.length === matchCount){
		alert("Congradulations! You have contained all of the abnormalities!");
		hideCard();
		showFireworks();
		
	}
	
};

const hideCard=()=>{
		const cards = document.querySelectorAll(".card");
		cards.forEach(card=>{
			card.style.visibility='hidden';
			
		});
		
		setTimeout( ()=>{
			location.reload();
		}, 2000
		);
	
};

const showFireworks = () => {
  const canvas = document.createElement('canvas');
  canvas.className = 'fireworks-canvas';
  document.body.appendChild(canvas);
  canvas.width = window.innerWidth;
  canvas.height = window.innerHeight;
  const ctx = canvas.getContext('2d');
  const fireworks = [];
  // Create a fireworks particle
  function createFirework(x, y) {
    const particles = [];
    const numParticles = 100;
    for (let i = 0; i < numParticles; i++) {
      particles.push({
        x: x,
        y: y,
        dx: Math.random() * 4 - 2,
        dy: Math.random() * 4 - 2,
        size: Math.random() * 2 + 1,
        life: Math.random() * 60 + 60,
        color: `hsl(${Math.random() * 360}, 100%, 50%)`
      });
    }
    return particles;
  }
  function updateFireworks() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    fireworks.forEach((firework, index) => {
      firework.forEach((particle, i) => {
        particle.x += particle.dx;
        particle.y += particle.dy;
        particle.size *= 0.999; // Gradually shrink
        particle.life -= 1;
        ctx.beginPath();
        ctx.arc(particle.x, particle.y, particle.size, 0, Math.PI * 2);
        ctx.fillStyle = particle.color;
        ctx.fill();
        if (particle.life <= 0) {
          firework.splice(i, 1);
        }
      });
      if (firework.length === 0) {
        fireworks.splice(index, 1);
      }
    });
    // Randomly create new fireworks
    if (Math.random() < 0.1) {
      fireworks.push(createFirework(Math.random() * canvas.width, Math.random() * canvas.height));
    }
    requestAnimationFrame(updateFireworks);
  }
  updateFireworks();
  // Stop the fireworks after 10 seconds
  setTimeout(() => {
    fireworks.length = 0; // Clear the fireworks array
    canvas.remove(); // Remove the canvas from the DOM
location.reload(); // Refresh the page
  }, 30000); // 10 seconds
};

window.onload=()=>{
		speakAddress("Hello Agent!");
		startTimer();
		loadGame();
	
};









